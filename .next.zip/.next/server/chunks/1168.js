"use strict";
exports.id = 1168;
exports.ids = [1168];
exports.modules = {

/***/ 1168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Hz": () => (/* binding */ addAmountValue),
  "uK": () => (/* binding */ addContact),
  "X5": () => (/* binding */ addSliderImage),
  "hb": () => (/* binding */ addUpiId),
  "KW": () => (/* binding */ adminAddBalance),
  "TZ": () => (/* binding */ adminChangePassword),
  "$g": () => (/* binding */ adminLogin),
  "rE": () => (/* binding */ adminLogout),
  "E7": () => (/* binding */ adminRegister),
  "AF": () => (/* binding */ createAppLink),
  "fb": () => (/* binding */ createBids),
  "MF": () => (/* binding */ createCloseWinner),
  "lx": () => (/* binding */ createHowToPlay),
  "H$": () => (/* binding */ createOpenWinner),
  "iX": () => (/* binding */ createPin),
  "Wv": () => (/* binding */ createWithdrawRequest),
  "wW": () => (/* binding */ declareCloseWinner),
  "_H": () => (/* binding */ declareOpenWinner),
  "Pw": () => (/* binding */ getAllBets),
  "dV": () => (/* binding */ getAllSliderImage),
  "aX": () => (/* binding */ getAllWinner),
  "Lk": () => (/* binding */ getAllWithdrawRequest),
  "x8": () => (/* binding */ getBetCategory),
  "vS": () => (/* binding */ getContact),
  "JR": () => (/* binding */ getDaysByCategoryId),
  "Tv": () => (/* binding */ getGlobalSettings),
  "YN": () => (/* binding */ getHowToPlay),
  "gY": () => (/* binding */ getOverAllBid),
  "q3": () => (/* binding */ getPaymentInfo),
  "wn": () => (/* binding */ getTotalBidAnk),
  "PR": () => (/* binding */ getUser),
  "GA": () => (/* binding */ getUserById),
  "es": () => (/* binding */ getUserCount),
  "jO": () => (/* binding */ getUserDebitOrCreditWalletHistory),
  "pj": () => (/* binding */ getWinnerResultChart),
  "ag": () => (/* binding */ getWithdrawRequest),
  "$6": () => (/* binding */ transferReport),
  "zO": () => (/* binding */ updateAllBets),
  "zT": () => (/* binding */ updateBatCategory),
  "RZ": () => (/* binding */ updateDays),
  "$9": () => (/* binding */ updateSliderImage),
  "Nq": () => (/* binding */ updateUser),
  "Ce": () => (/* binding */ updateWithdrawRequest),
  "QO": () => (/* binding */ userChangePassword),
  "Au": () => (/* binding */ userGameHistory),
  "yx": () => (/* binding */ userGameHistoryReport),
  "Be": () => (/* binding */ userWalletHistory),
  "Fb": () => (/* binding */ winningReport),
  "O$": () => (/* binding */ withdrawRequestAdmin)
});

// UNUSED EXPORTS: createGameWinner, getAmountValue, getAppLink, getBatCategoryByToday, getUpiId

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./src/helpers/Api.js

// export const URL = 'http://alphadevinfotech.com:5000/api/v1/'
const URL = 'https://api.kalyandpboss.co.in/api/v1/';
// export const URL = 'http://192.168.1.7:5000/api/v1/'
let authToken = '';
// Check if localStorage is available before using it
if (typeof localStorage !== 'undefined') {
    const userData = JSON.parse(localStorage.getItem('user'));
    console.log('userData', userData);
    authToken = (userData === null || userData === void 0 ? void 0 : userData.token) || '';
}
const axiosInstance = external_axios_default().create({
    baseURL: URL,
    headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: authToken
    }
});
axiosInstance.interceptors.request.use((config)=>{
    // Retrieve token from localStorage before each request
    const userData = JSON.parse(localStorage.getItem('user'));
    authToken = (userData === null || userData === void 0 ? void 0 : userData.token) || '';
    if (authToken) {
        config.headers['Authorization'] = authToken;
    }
    // console.log('window.location.href1', window.location.pathname)
    if (window.location.pathname != '/admin/login/') {
        // console.log('inside token expired')
        const tokenExpired = isTokenExpired(authToken);
        if (tokenExpired) {
            // Handle token expiration (e.g., log out the user)
            console.log('Token expired!');
            window.location.href = '/admin/login';
        // You can perform actions here like logging out the user or redirecting to a login page
        }
    }
    return config;
}, (error)=>{
    console.log(error, 'this is error call');
    return Promise.reject(error);
});
function isTokenExpired(token) {
    if (!token) return true // Token doesn't exist, so consider it expired
    ;
    try {
        const tokenData = JSON.parse(atob(token.split('.')[1])) // Decoding token payload
        ;
        const expirationTime = tokenData.exp * 1000 // Expiration time in milliseconds
        ;
        const currentTime = Date.now() // Current time in milliseconds
        ;
        return expirationTime < currentTime // Token is expired if expiration time is less than current time
        ;
    } catch (error) {
        console.error('Error parsing token:', error);
        return true // Treat any parsing error as token expired
        ;
    }
}
/* harmony default export */ const Api = (axiosInstance);

;// CONCATENATED MODULE: ./src/helpers/service.js

//Auth api
function adminLogin(credentials) {
    return Api.post(`/auth/adminLogin`, credentials).then((res)=>{
        console.log(res);
        return res.data;
    }).catch((error)=>{
        return error;
    });
}
function adminRegister(credentials) {
    return Api.post(`/auth/createAdmin`, credentials).then((res)=>{
        console.log(res);
        return res.data;
    }).catch((error)=>{
        return error;
    });
}
function adminLogout() {
    return Api.get(`/auth/adminLogout`).then((res)=>{
        console.log(res);
        return res.data;
    }).catch((error)=>{
        return error;
    });
}
let getUser = (isBetting)=>{
    return Api.get(`/master/getAllUsers?page=1&limit=1000&isBetting=${isBetting}`).then((res)=>{
        console.log(res);
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getBetCategory = ()=>{
    return Api.get(`game/getBatCategory`).then((res)=>{
        console.log(res);
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getDaysByCategoryId = (id)=>{
    return Api.get(`game/getDaysByCategoryId?id=${id}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let updateDays = (data)=>{
    return Api.post(`/game/updateDays`, {
        data
    }).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getBatCategoryByToday = ()=>{
    return apis.get(`game/getBatCategoryByToday`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let createOpenWinner = (data)=>{
    return Api.post('game/createOpenWinner', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let declareOpenWinner = (data)=>{
    return Api.post('game/declareOpenWinner', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let createCloseWinner = (data)=>{
    return Api.post('game/createCloseWinner', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let declareCloseWinner = (data)=>{
    return Api.post('game/declareCloseWinner', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let createBids = (data)=>{
    return Api.post('game/createBatCategory', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getWinnerResultChart = (sDate, eDate)=>{
    return Api.get(`game/getWinnerResultChart?startDate=${sDate}&endDate=${eDate}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getAllWinner = (data)=>{
    return Api.get('game/getAllWinnerUser', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let createAppLink = (data)=>{
    return Api.post('master/addAppLink', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getAppLink = ()=>{
    return apis.get(`master/getAppLink`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let addUpiId = (data)=>{
    return Api.post('master/addUpiId', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getUpiId = ()=>{
    return apis.get(`master/getUpiId`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let addAmountValue = (data)=>{
    return Api.post('master/addAmountValue', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getAmountValue = ()=>{
    return apis.get(`master/getAmountValue`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getGlobalSettings = ()=>{
    return Api.get(`master/getGlobalSettings`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let addContact = (data)=>{
    return Api.post('master/addContact', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getContact = ()=>{
    return Api.get('master/getContact').then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let createHowToPlay = (data)=>{
    return Api.post('master/createHowToPlay', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getHowToPlay = ()=>{
    return Api.get('master/getHowToPlay').then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let addSliderImage = (sliderData)=>{
    let formData = new FormData();
    for(let key in sliderData){
        formData.append(key, sliderData[key]);
    }
    return Api.post('master/addSliderImage', formData, {
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    }).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getAllSliderImage = ()=>{
    return Api.get('master/getAllSliderImage').then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let updateSliderImage = (data)=>{
    return Api.post('master/updateSliderImage', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let updateUser = (data)=>{
    return Api.put('master/updateUserStatus', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getUserById = (userId)=>{
    console.log('userId in api ', userId);
    return Api.get(`auth/getUserById/${userId}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let adminChangePassword = (data)=>{
    return Api.post('auth/adminChangePassword', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getPaymentInfo = (userId)=>{
    return Api.get(`auth/getPaymentInfo?userId=${userId}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let userWalletHistory = (userId)=>{
    return Api.get(`/game/getUserWalletHistory?pageNumber=1&pageSize=100&userId=${userId}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getUserDebitOrCreditWalletHistory = (userId, transactionType)=>{
    return Api.get(`/game/getUserWalletHistory?pageNumber=1&pageSize=100&userId=${userId}&transactionType=${transactionType}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let userGameHistory = (userId)=>{
    return Api.get(`/game/getGameHistory?pageNumber=1&pageSize=1000&userId=${userId}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let updateBatCategory = (data)=>{
    return Api.post('/game/updateBatCategory', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let createPin = (userId, data)=>{
    return Api.post(`/auth/createPin?userId=${userId}`, data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let adminAddBalance = (data)=>{
    return Api.post('/game/adminAddBalance', data).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getUserCount = ()=>{
    return Api.get(`/master/getUserCount`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getAllBets = ()=>{
    return Api.get(`/game/getAllBets`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let winningReport = (startDate, endDate, betCategoryId, state)=>{
    return Api.get(`/game/winnerHistory?startDate=${startDate}&endDate=${endDate}&betCategoryId=${betCategoryId}&state=${state}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let withdrawRequestAdmin = (startDate, endDate)=>{
    return Api.get(`/game/getWithdrawRequest?pageNumber=1&pageSize=1000&startDate=${startDate}&endDate=${endDate}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let updateAllBets = (bodyData)=>{
    return Api.post(`/game/updateAllBet`, bodyData).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let userChangePassword = (userId, password)=>{
    return Api.post(`/auth/changePassword?userId=${userId}`, password).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getWithdrawRequest = (userId)=>{
    return Api.get(`/game/getWithdrawRequest?pageNumber=1&pageSize=100&userId=${userId}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let createWithdrawRequest = (user)=>{
    return Api.post(`/game/createWithdrawRequest`, user).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getTotalBidAnk = (bodyData)=>{
    return Api.post(`/game/getTotalBidAnk`, bodyData).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getOverAllBid = (bodyData)=>{
    return Api.post(`/game/getBidAmountByBid`, bodyData).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let transferReport = (date)=>{
    console.log('date', date);
    return Api.get(`/game/transferReport?pageNumber=1&pageSize=1000&date=${date}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let createGameWinner = (parameter)=>{
    return apis.post(`/game/createWinner`, parameter).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let getAllWithdrawRequest = ()=>{
    return Api.get(`/game/getWithdrawRequest?pageNumber=1&pageSize=1000`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let updateWithdrawRequest = (sliderData)=>{
    let formData = new FormData();
    for(let key in sliderData){
        formData.append(key, sliderData[key]);
    }
    return Api.post('game/updateWithdrawRequest', formData, {
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    }).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};
let userGameHistoryReport = (startDate, endDate, betId, betCategoryId)=>{
    return Api.get(`/game/getGameHistory?pageSize=100&pageNumber=1&startDate=${startDate}&endDate=${endDate}&betId=${betId}&betCategoryId=${betCategoryId}`).then((res)=>{
        return res.data;
    }).catch((error)=>{
        return error;
    });
};


/***/ })

};
;